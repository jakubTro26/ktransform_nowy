<?php 

	/* Event Box  ---------------------------------------------*/
	
	add_shortcode('event_box', 'jx_ievent_event_box');
	
	function jx_ievent_event_box($atts, $content = null) { 
		extract(shortcode_atts(array(
			'start_date' => '',
			'end_date' => '',
			'month' => '',
			'pretitle' => '',
			'title' => '',
			'location' => ''
		), $atts)); 
		 
		
		//initial variables
		$out='';
		$end_date_set=''; 
		
		if ($end_date):
		$end_date_set='<span>-'.$end_date.'</span>';
		endif;
		//function code
			
			$out ='
				<div class="jx-ievent-event-box">
					<div class="jx-ievent-event-date">
						<div class="jx-ievent-event-day">'.$start_date.''.$end_date_set.'</div>
						<div class="jx-ievent-event-month jx-ievent-uppercase">'.$month.'</div>
					</div>
					<div class="jx-ievent-event-title-box">
						<div class="jx-ievent-event-pretitle">'.$pretitle.'</div>
						<div class="jx-ievent-event-title">'.$title.'</div>
						<div class="jx-ievent-event-location">'.$location.'</div>
					</div>
				</div> 
			';
			

		//return output
		return $out;
	}
?>