<?php 

	/* Event Counter  ---------------------------------------------*/
	
	add_shortcode('event_form', 'jx_ievent_event_form');
	
	function jx_ievent_event_form($atts, $content = null) { 
		extract(shortcode_atts(array(
			'type' => '',
			'start_date' => '',
			'end_date' => '',
			'month' => '',
			'pretitle' => '',
			'option_1' => '',
			'title' => '',			
		), $atts)); 
		 
		$id = rand(0,100);
		//initial variables
		$out=''; 
		$headers='';
		$option_sep='';
		$option_list='';		
		$end_date_set='';
		$form_1='';
		$form_2='';
		
		if ($end_date):
		$end_date_set='<span>-'.$end_date.'</span>';
		endif;
		
		$i=0;
		global $post;
		
		$option_sep=explode(",", $option_1);
		
		foreach($option_sep as $option_comma){
					
			$option_list .='<option value="'.strtolower($option_comma).'">'.ucfirst($option_comma).'</option>';  
			$i++;
		
		}		
				
			switch($type){ 
		
			case '1': 			
			
			if (get_post_meta($post->ID,'jx_ievent_form_custom_chkd',true)):
				$form_1=do_shortcode(get_post_meta($post->ID,'jx_ievent_form_custom_code',true));	
			else:
				$form_1='<form action="#" id="contactForm-register-'.$id.'" method="post"  class="toggle-disabled">
								<div class="jx-ievent-ticket-first-name">
									<input type="text" id="name-register-'.$id.'" name="tab_reg_name" placeholder="'.esc_html__('Full Name','ievent').'" class="jx-ievent-form-text" data-validation="length" data-validation-length="min3" data-validation="required"/>
									<!-- First Name Textbox -->
								</div>
								<div class="jx-ievent-ticket-email">
									<input type="text" id="email-register-'.$id.'" name="tab_reg_email" placeholder="'.esc_html__('Email Address','ievent').'" class="jx-ievent-form-text" data-validation="email" data-validation="required"/>
									<!-- Email Name Textbox -->
								</div>
			
								<div class="jx-ievent-ticket-phone">
									<input type="text" id="subject-register-'.$id.'" name="tab_reg_phone" placeholder="'.esc_html__('Phone Number','ievent').'" class="jx-ievent-form-text" data-validation="required"/>
									<!-- Phone Textbox -->
								</div>
							
								<div class="jx-ievent-ticket-type">
									<select name="tab_reg_ticket_type" class="select-box" data-validation="required">
									  '.$option_list.'
									</select>
								</div>

								<input type="hidden" name="submitted" id="submitted-'.$id.'" value="true" />
								<input type="submit" id="submit-register-'.$id.'" name="submit-register" class="jx-ievent-form-btn jx-ievent-btn-default" value="'.esc_html__('REGISTER NOW','ievent').'" />
								
								'.wp_nonce_field( 'add-user', 'add-nonce' ).'<!-- a little security to process on submission -->
	        					<input name="action" type="hidden" value="contactForm-register-'.$id.'" />
								<!-- Submit Button -->
								<div class="jx-preload">
									<div class="jx-load-spinner">
									  <div class="rect1"></div>
									  <div class="rect2"></div>
									  <div class="rect3"></div>
									  <div class="rect4"></div>
									  <div class="rect5"></div>
									</div>
								</div>
							</form>';			
			endif;
			
			$out  ='
			<div class="jx-ievent-event-box jx-ievent-event-box-register">                                    
				
				<div class="jx-ievent-event-date">
					<div class="jx-ievent-event-day">'.$start_date.''.$end_date_set.'</div>
					<div class="jx-ievent-event-month jx-ievent-uppercase">'.$month.'</div>
				</div>
				
				<div class="jx-ievent-event-title-box">
					<div class="jx-ievent-event-pretitle">'.$pretitle.'</div>
					<div class="jx-ievent-event-title">'.$title.'</div>
					<div class="jx-ievent-event-register">
						'.$form_1.'
					</div>
				</div>
			
			</div> 
			';
			
			break;
			
			case '2':
			
			if (get_post_meta($post->ID,'jx_ievent_form_custom_chkd',true)):
				$form_2=do_shortcode(get_post_meta($post->ID,'jx_ievent_form_custom_code',true));	
			else:
				$form_2='<form action="#" id="contactForm-register-'.$id.'" method="post" class="toggle-disabled">
								<div class="jx-ievent-ticket-first-name">
									<input type="text" id="first_name-register-'.$id.'" name="tab_reg_name" placeholder="'.esc_html__('Full Name','ievent').'" class="jx-ievent-form-text" data-validation="length" data-validation-length="min3" data-validation="required"/>
									<!-- First Name Textbox -->
								</div>
								<div class="jx-ievent-ticket-email">
									<input type="text" id="email-register-'.$id.'" name="tab_reg_email" placeholder="'.esc_html__('Email Address','ievent').'" class="jx-ievent-form-text" data-validation="email" data-validation="required"/>
									<!-- Email Name Textbox -->
								</div>
			
								<div class="jx-ievent-ticket-phone">
									<input type="text" id="subject-register-'.$id.'" name="tab_reg_phone" placeholder="'.esc_html__('Phone Number','ievent').'" class="jx-ievent-form-text" data-validation-length="number" data-validation="required"/>
									<!-- Phone Textbox -->
								</div>
								
								<div class="jx-ievent-ticket-type">
									<select name="reg_ticket_type" class="select-box" data-validation="required">
										'.$option_list.'
									</select>
								</div>
								
								<input type="hidden" name="submitted" id="submitted-'.$id.'" value="true" />
								<input type="submit" id="submit-register-'.$id.'" name="submit-register" class="jx-ievent-form-btn jx-ievent-btn-default" value="'.esc_html__('REGISTER NOW','ievent').'" />
								'.wp_nonce_field( 'add-user', 'add-nonce' ).'<!-- a little security to process on submission -->
	        					<input name="action" type="hidden" value="contactForm-register-'.$id.'" />
								<div class="jx-preload">
									<div class="jx-load-spinner">
									  <div class="rect1"></div>
									  <div class="rect2"></div>
									  <div class="rect3"></div>
									  <div class="rect4"></div>
									  <div class="rect5"></div>
									</div>
								</div>
							</form>';			
			endif;
			
			$out  ='
			<div class="jx-ievent-event-box jx-ievent-event-box-register jx-ievent-register-box-2">                                    
				
				<div class="jx-ievent-event-date">
					<div class="jx-ievent-event-day">'.$start_date.'-'.$end_date.' '.$month.'</div>
				</div>
				
				<div class="jx-ievent-event-title-box">
					<div class="jx-ievent-event-pretitle">'.$pretitle.'</div>
					<div class="jx-ievent-event-title">'.$title.'</div>
					<div class="jx-ievent-event-register">
						'.$form_2.'
					</div>
				</div>
			
			</div>
			';
			
			
			break;
			
		}
			
		
		
		$out .="<script type='text/javascript'>                 	
                    	jQuery('form').on( 'submit', function( event ) {
						    event.preventDefault();
							event.stopImmediatePropagation();
						    jQuery('.jx-ievent-alert').empty();
							jQuery('.jx-preload',this).addClass('show');
							
							var data = {
									action: 'submit_form',
									data: jQuery(this).serialize()
								};
							jQuery.post(ajaxurl, data, function(response) {
								console.log(response);
								if(response.success){
									jQuery('.jx-preload').removeClass('show')									
									jQuery('.jx-ievent-alert').addClass('success');
									jQuery('.jx-ievent-alert').addClass('show');
									jQuery('.jx-ievent-alert').append(response.success);
									jQuery('.jx-ievent-alert').addClass('hide');
									
									jQuery( 'form' ).each(function(){this.reset();});
																	
								}
								
							},'json');
							
							
							
						
						});
                    </script>";	

		//return output
		return $out;
	}


?>