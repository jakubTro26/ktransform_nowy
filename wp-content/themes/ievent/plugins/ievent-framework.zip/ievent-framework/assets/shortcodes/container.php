<?php 

	/* Container  ---------------------------------------------*/
	
	add_shortcode('container', 'jx_ievent_container');
	
	function jx_ievent_container($atts, $content = null) { 
		extract(shortcode_atts(array(
			'bg_color' => '',
			'bg_image' => '',
			'bg_pos' => '',
			'bg_icon' => '',
			'class' => '',
			'id' => '',
			'padding'=>'',
			'jx_tint'=>'jx-ievent-tint-black',
			'container_class' => ''
			
			
			
		), $atts));
		
		$padding_class='';
		
		if ($padding=='jx-padding'):
			$padding_class="jx-ievent-padding";
		endif;
		 
		 
		
		//initial variables
		$out=''; 
		
		$background_color ="";
		
		if($bg_color =="white") {
		$background_color ="jx-ievent-white-bg";
		} elseif ($bg_color =="grey") {
		$background_color ="jx-ievent-grey-bg";
		} elseif ($bg_color =="default") {
		$background_color ="jx-ievent-default-bg";
		}
		
		if($bg_image =="") {
		$parallax_image ="";
		} else {
		$parallax_image ="<div class='parallax-no-height ".$jx_tint."' style='background-image:url(".$bg_image."); background-position:".$bg_pos."'></div>";
		}
		
		if($bg_icon =="") {
		$background_icon ="";
		} else {
		$background_icon ="<div class='container-bg-icon'><i class='fa ".$bg_icon."'></i></div>";
		}
		
		if ($id!=''):
			$id_value="id='".$id."'";
		else:
			$id_value='';
		endif;
		
		//function code
			
			$out ='
			<div '.$id_value.' class="jx-ievent-container container-no-margin '.$padding_class.' '.$background_color.' '.$class.'">
				'.$parallax_image.'
				<!-- Background Image -->
				'.$background_icon.'
				<!-- Background Icon -->
				<div class="container '.$container_class.'">'.do_shortcode($content).'</div>
			</div>
			';
			

		//return output
		return $out;
	}
	
	
	

?>