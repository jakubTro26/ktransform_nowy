<?php 
	
	
	/* Portfolio Image ---------------------------------------------*/
	
	add_shortcode('portfolio', 'jx_ievent_portfolio_image');
	
	function jx_ievent_portfolio_image($atts, $content = null) { 
		extract(shortcode_atts(array(
			'title' => '',
			'sub_title' => '',
			'box_pos_1'=>'1',
			'box_title_1'=>'25 Jan',
			'box_subtitle_1'=>'Day 1',
			'box_pos_2'=>'6',
			'box_title_2'=>'26 Jan',
			'box_subtitle_2'=>'Day 2',
			'box_pos_3'=>'12',
			'box_title_3'=>'27 Jan',
			'box_subtitle_3'=>'Day 3',
			'category' => '',
			'post_count' => '16'
				), $atts)); 
		 
		
		//initial variables
		$out='';
		$image_size=''; 
		$i=0; 
		
		$image_size = array('port-1','port-2');
		
		$args = array('post_type' => 'portfolio','orderby' => 'date', 'order' => 'ASC','showposts' => $post_count ); 
		$loop = new WP_Query( $args ); 		
		
		
		$out .='<div class="jx-gallery">';
			
		while ( $loop->have_posts() ) : $loop->the_post();  
			

			
			$random_size = rand(0,1);
    		$get_myimage_size = $image_size[$random_size];
			
			$post_thumbnail_id = get_post_thumbnail_id();
			$post_thumbnail_url = wp_get_attachment_image_src($post_thumbnail_id,'large', true);

			if ($i==0):
				$image_size_class ='grid-item-height2 grid-item-width2';
			elseif ($i==15 or $i==16 ):
				$image_size_class ='grid-item-width2-only';
			else:
				$image_size_class ='small_grid';
			endif;
			
			
			if ($box_pos_1==$i):
			
			$out .='<div class="jx-ievent-grid-item jx-ievent-date-box"> 
                 		
                        <div class="jx-ievent-date-box">
                        	<div class="jx-ievent-date">'.$box_title_1.'</div>
                            <div class="jx-ievent-day">'.$box_subtitle_1.'</div>
                        </div>
                                                
                    </div>';
					
			$out .='<div class="jx-ievent-grid-item '.$image_size_class.'">                    	
                        <div class="jx-ievent-image jx-ievent-image-wrapper">'.get_the_post_thumbnail(get_the_ID(),'port-1').'
                        
                        	<div class="jx-ievent-image-overlayer"></div>
                            <div class="jx-ievent-image-hover">
                            	<a href="'.$post_thumbnail_url[0].'" data-rel="prettyPhoto"><i class="fa fa-expand"></i></a>
                            </div>
                        	<!--Image Hover -->
                        </div>                        
                    </div>';				
			
			elseif ($box_pos_2==$i):
			
			$out .='<div class="jx-ievent-grid-item jx-ievent-date-box"> 
                 		
                        <div class="jx-ievent-date-box">
                        	<div class="jx-ievent-date">'.$box_title_2.'</div>
                            <div class="jx-ievent-day">'.$box_subtitle_2.'</div>
                        </div>
                                                
                    </div>';
			$out .='<div class="jx-ievent-grid-item '.$image_size_class.'">                    	
                        <div class="jx-ievent-image jx-ievent-image-wrapper">'.get_the_post_thumbnail(get_the_ID(),'port-1').'
                        
                        	<div class="jx-ievent-image-overlayer"></div>
                            <div class="jx-ievent-image-hover">
                            	<a href="'.$post_thumbnail_url[0].'" data-rel="prettyPhoto"><i class="fa fa-expand"></i></a>
                            </div>
                        	<!--Image Hover -->
                        </div>                        
                    </div>';
			
			elseif ($box_pos_3==$i):
			
			$out .='<div class="jx-ievent-grid-item jx-ievent-date-box"> 
                 		
                        <div class="jx-ievent-date-box">
                        	<div class="jx-ievent-date">'.$box_title_3.'</div>
                            <div class="jx-ievent-day">'.$box_subtitle_3.'</div>
                        </div>
                                                
                    </div>';
					
			$out .='<div class="jx-ievent-grid-item '.$image_size_class.'">                    	
                        <div class="jx-ievent-image jx-ievent-image-wrapper">'.get_the_post_thumbnail(get_the_ID(),'port-1').'
                        
                        	<div class="jx-ievent-image-overlayer"></div>
                            <div class="jx-ievent-image-hover">
                            	<a href="'.$post_thumbnail_url[0].'" data-rel="prettyPhoto"><i class="fa fa-expand"></i></a>
                            </div>
                        	<!--Image Hover -->
                        </div>                        
                    </div>';
			
			else:		
			
			$out .='<div class="jx-ievent-grid-item '.$image_size_class.'">                    	
                        <div class="jx-ievent-image jx-ievent-image-wrapper">'.get_the_post_thumbnail(get_the_ID(),'port-1').'
                        
                        	<div class="jx-ievent-image-overlayer"></div>
                            <div class="jx-ievent-image-hover">
                            	<a href="'.$post_thumbnail_url[0].'" data-rel="prettyPhoto"><i class="fa fa-expand"></i></a>
                            </div>
                        	<!--Image Hover -->
                        </div>                        
                    </div>';
			endif;
			
			$i++;
			endwhile;
			wp_reset_query(); 
			
		$out .='</div>';	
		//return output
		return $out;
	}




	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_portfolio' );
	
	
	function vc_portfolio() {	
		vc_map(array(
      "name" => esc_html__( "Portfolio", "TEXT_DOMAIN" ),
      "base" => "portfolio",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_gallery.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Portfolio','TEXT_DOMAIN'),
      "params" => array(
		 		 
		  
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "First Box Images Count", "TEXT_DOMAIN" ),
            "param_name" => "box_pos_1",
			"value" => "1", //Default Counter Up Text
            "description" => esc_html__( "You Can Change Count", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "First Date Box", "TEXT_DOMAIN" ),
            "param_name" => "box_title_1",
			"value" => "25 Jan", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Day", "TEXT_DOMAIN" ),
            "param_name" => "box_subtitle_1",
			"value" => "1", //Default Counter Up Text
            "description" => esc_html__( "Type Day Here", "TEXT_DOMAIN" )
         ),
	
		
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Second Box Images Count", "TEXT_DOMAIN" ),
            "param_name" => "box_pos_2",
			"value" => "6", //Default Counter Up Text
            "description" => esc_html__( "You Can Change Count", "TEXT_DOMAIN" )
         ),
		 
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Second Date Box", "TEXT_DOMAIN" ),
            "param_name" => "box_title_2",
			"value" => "26 Jan", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
		 
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Day", "TEXT_DOMAIN" ),
            "param_name" => "box_subtitle_2",
			"value" => "Day 2", //Default Counter Up Text
            "description" => esc_html__( "Type Day Here", "TEXT_DOMAIN" )
         ),
		 
		 
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Third Box Images Count", "TEXT_DOMAIN" ),
            "param_name" => "box_pos_3",
			"value" => "12", //Default Counter Up Text
            "description" => esc_html__( "You Can Change Count", "TEXT_DOMAIN" )
         ),
		 
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Third Date Box", "TEXT_DOMAIN" ),
            "param_name" => "box_title_3",
			"value" => "27 Jan", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
		 
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Day", "TEXT_DOMAIN" ),
            "param_name" => "box_subtitle_3",
			"value" => "Day 3", //Default Counter Up Text
            "description" => esc_html__( "Type Day Here", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Post Count", "TEXT_DOMAIN" ),
            "param_name" => "post_count",
			"value" =>"16", //Default Counter Up Text
            "description" => esc_html__( "You Can Change Count", "TEXT_DOMAIN" )
         )

		 

      )
   )); 
	}
	 


?>