<?php 
	/* Counter Up Group  ---------------------------------------------*/
	
	add_shortcode('counter_up_group', 'jx_ievent_counter_up_group');
	
	function jx_ievent_counter_up_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'color_style' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		$dark_light_color ="";
		
		if($color_style =="light") {
		$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
		$dark_light_color ="jx-ievent-dark";
		}
		
		//function code
		$out ='<div class="jx-ievent-countup '.$dark_light_color.'">'.do_shortcode($content).'</div>'; 
			
		
		//return output
		return $out;
	}
	/* Counter Up  ---------------------------------------------*/
	
	add_shortcode('counter_up', 'jx_ievent_counter_up');
	
	function jx_ievent_counter_up($atts, $content = null) { 
		extract(shortcode_atts(array(
					'count_up' => '',
					'count_up_icon' => '',
					'count_up_text' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			$out ='
			<div class="four columns count-item">			
			
				<div class="jx-ievent-counter-item">            
					<div class="jx-ievent-counter-icon"><i class="line-icon '.$count_up_icon.'"></i></div>
					<!-- Counter icon -->
					
					<div class="jx-ievent-counter-info">
						<div class="jx-ievent-counter-text">'.$count_up_text.'</div>
						<div class="jx-ievent-counter-number jx-ievent-counter-up">'.$count_up.'</div>
					</div>
					<!-- Counter info -->
            	</div>
			</div>
			<!-- Item 01 -->
			';
			
		
		//return output
		return $out;
	}
	
	/* Counter Up  ---------------------------------------------*/
	
	add_shortcode('vc_counter_up', 'vc_ievent_counter_up');
	
	function vc_ievent_counter_up($atts, $content = null) { 
		extract(shortcode_atts(array(
					'color_style' => '',
					'count_up' => '',
					'count_up_icon' => '',
					'count_up_text' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$dark_light_color ="";
		if($color_style =="light") {
			$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
			$dark_light_color ="jx-ievent-dark";
		}
		
		//function code
			$out ='
			<div class="jx-ievent-countup '.$dark_light_color.'">
	
				<div class="count-item">	
					<div class="jx-ievent-counter-item">
						<div class="jx-ievent-counter-icon"><i class="line-icon '.$count_up_icon.'"></i></div>
						<!-- Counter icon -->
	
						<div class="jx-ievent-counter-info">
							<div class="jx-ievent-counter-text">'.$count_up_text.'</div>
							<div class="jx-ievent-counter-number jx-ievent-counter-up">'.$count_up.'</div>
						</div>	
						<!-- Counter info -->	
					</div>	
				</div>	
				<!-- Item 01 -->
			</div>
			';
					
		//return output
		return $out;
	}
	
	add_action( 'vc_before_init', 'vc_count_up' );
	
	
	function vc_count_up() {	
		vc_map(array(
		  "name" => esc_html__( "Count Up", "TEXT_DOMAIN" ),
		  "base" => "vc_counter_up",
		  "class" => "",
		  "icon" => get_template_directory_uri().'/images/icon/vc_count-up.png',
		  "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
		  "description" => __('Add Count Up','TEXT_DOMAIN'),
		  "params" => array(
					 	
			
			
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Text Style",'TEXT_DOMAIN'),
				 "param_name" => "color_style",
				 "value" => array(   
					__('Light/Dark', 'TEXT_DOMAIN') => 'Select Text Style',
					__('Light', 'TEXT_DOMAIN') => 'light',
					__('Dark', 'TEXT_DOMAIN') => 'dark',
						),
			),
				
			array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
					'param_name' => 'count_up_icon',
					'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'linecons',
					'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
					'save_always' => true
				),
			 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Count Number", "TEXT_DOMAIN" ),
				"param_name" => "count_up",
				"value" => "345", //Default Counter Up Text
				"description" => esc_html__( "Type count number", "TEXT_DOMAIN" )
			 ),
			 
			 array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Count Text", "TEXT_DOMAIN" ),
				"param_name" => "count_up_text",
				"value" => "Developer", //Default Counter Up Text
				"description" => esc_html__( "Type text below counter", "TEXT_DOMAIN" )
			 )					 
		  )
	   ));
    
	}
	
	
	
	
	
	
?>