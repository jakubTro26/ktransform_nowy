<?php 

	/* Partners  ---------------------------------------------*/
	
	add_shortcode('progress_bar_group', 'ievent_progress_bar_group');
	
	function ievent_progress_bar_group($atts, $content = null) { 
		extract(shortcode_atts(array(
				'type' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code
		
		switch($type){ 

		case '1':
		
		$out ='
		<div class="jx-skillsbar-2">
			<div class="skillsbar-head">
				<div class="left"></div>
				<div class="item-position">'.do_shortcode($content).'</div>
			</div>
		</div>
		'; 
			
		break;
		
		case '2':
		
		$out ='
		<div class="jx-skillsbar-3 jx-bar-border jx-light">
			<div class="skillsbar-head">
			<div class="left"></div>
				<div class="item-position"> '.do_shortcode($content).'</div>
			</div>
		</div>
		'; 
			
		break;
		
		case '3':
		
		$out ='
	   <div class="jx-skillsbar-4 jx-bar-border jx-light jx-stripes jx-animated-stripes" data-appear-progress-animation>
		<div class="skillsbar-head">
		<div class="left"></div>
			<div class="item-position">'.do_shortcode($content).'</div>
			</div>
		</div>
		'; 
			
		break;
		
		case '4':
		
		$out ='
	  <div class="jx-skillsbar-6 jx-light">
		<div class="skillsbar-head">
		<div class="left"></div>
			<div class="item-position">  '.do_shortcode($content).'</div>
			</div>
		</div>
		'; 
			
		break;
		
		
		case '5':
		
		$out ='
			<div class="jx-skill-level">
			<!-- Skillsbar #1 -->
			<div class="jx-skillsbar-1">                                				
			'.do_shortcode($content).'
			</div>
			<!-- Skillsbar#1 -->		
			</div>
		'; 
			
		break;

		}
		
		//return output
		return $out;
	}



	/* Partners  ---------------------------------------------*/
	
	add_shortcode('progress_bar', 'ievent_progress_bar');
	
	function ievent_progress_bar($atts, $content = null) { 
		extract(shortcode_atts(array(
					'title' => 'HTML',
					'percentage' => '90'
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code

			$out ='
			<div class="skillbar clearfix" data-percent="'.$percentage.'%">
                <div class="skillbar-title">
                    <span>'.$title.'</span>
                </div>
				<div class="skillbar-bar" data-progress-animate="'.$percentage.'%">
                    <span class="percenttext">'.$percentage.'%</span>
                </div>
            </div> 
			';
			
			
			
			
		
		//return output
		return $out;
	}
	
	
	
	
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_progress_bar' );
	
	
	function vc_progress_bar() {	
		
		vc_map( array(
			"name" => __("Progress Bar Group", "TEXT_DOMAIN"),
			"base" => "progress_bar_group",
			"as_parent" => array('only' => 'progress_bar'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			"is_container" => true,
			"params" => array(
				// add params same as with any other content element
				
				
							
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Your Style",'TEXT_DOMAIN'),
				 "param_name" => "type",
				 "value" => array(   
						__('Select Your Style', 'TEXT_DOMAIN') => 'Select Your Style',
						__('Skills Bar - 1', 'TEXT_DOMAIN') => '1',
						__('Skills Bar - 2', 'TEXT_DOMAIN') => '2',
						__('Skills Bar - 3', 'TEXT_DOMAIN') => '3',
						__('Skills Bar - 4', 'TEXT_DOMAIN') => '4',
						__('Skills Bar - 5', 'TEXT_DOMAIN') => '5',
						),
			)

				
			),
			"js_view" => 'VcColumnView'
		)
		 );
		
		
		vc_map( array(
			"name" => __("Single Progress Bar", "TEXT_DOMAIN"),
			"base" => "progress_bar",
			"content_element" => true,
			"as_child" => array('only' => 'progress_bar_group'), // Use only|except attributes to limit parent (separate multiple values with comma)
			"params" => array(
				// add params same as with any other content element
								

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
				"param_name" => "title",
				"value" => "HTML", //Default Counter Up Text
				"description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
			),


			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Percent Number", "TEXT_DOMAIN" ),
				"param_name" => "percentage",
				"value" => "90", //Default Counter Up Text
				"description" => esc_html__( "Type Your Percent Number", "TEXT_DOMAIN" )
			)
				
				
				
			)
		) );
		//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
		if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
			class WPBakeryShortCode_progress_bar_group extends WPBakeryShortCodesContainer {
			}
		}
		if ( class_exists( 'WPBakeryShortCode' ) ) {
			class WPBakeryShortCode_progress_bar extends WPBakeryShortCode {
			}
		}
		
	}



?>