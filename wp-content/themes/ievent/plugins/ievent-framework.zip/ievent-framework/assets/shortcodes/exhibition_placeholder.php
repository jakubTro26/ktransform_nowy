<?php 
	/* Exhibition Placeholder Group  ---------------------------------------------*/
	
	add_shortcode('exhibition_placeholder_group', 'jx_ievent_exhibition_placeholder_group');
	
	function jx_ievent_exhibition_placeholder_group($atts, $content = null) { 
		extract(shortcode_atts(array(

				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code

		$out ='
		<div class="row"></div>		
			<div class="jx-ievent-map-company">                        	
				<ul>'.do_shortcode($content).'</ul>
			</div>
		';
		
		$out .='';
				
		//return output
		return $out;
	}



	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('exhibition_placeholder', 'jx_ievent_exhibition_placeholder');
	
	function jx_ievent_exhibition_placeholder($atts, $content = null) { 
		extract(shortcode_atts(array(
					'title' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='
			<li>
			<ul>'.do_shortcode($content).'</ul>
			</li>
			';

		
		//return output
		return $out;
	}
	



	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('exhibition_placeholder_point', 'jx_ievent_exhibition_placeholder_point');
	
	function jx_ievent_exhibition_placeholder_point($atts, $content = null) { 
		extract(shortcode_atts(array(
					'title' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='				
			<li>'.$title.'</li>
			';

		
		//return output
		return $out;
	}
	
	
	
	
	
	
	
	
	
	//Visual Composer
	
	add_shortcode('exhibition_placeholder_single', 'jx_ievent_exhibition_placeholder_single');
	
	function jx_ievent_exhibition_placeholder_single($atts, $content = null) { 
		extract(shortcode_atts(array(

			'company_lists' => '01.Rocko Co'

				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$comapny_line='';

		$sep_company = explode(',',$company_lists);
		
		//var_dump($sep_company);
		
		foreach ($sep_company as $company_name):		
		$comapny_line .='<li>'.$company_name.'</li>';		
		endforeach;
		
		//function code
		
			$out .='
			<div class="row"></div>		
			<div class="jx-ievent-map-company">                        	
			<ul>';
		

			$out .='
			<li>
				<ul>'.$comapny_line.'</ul>
			</li>
			';


			$out .='
			</ul>
			</div>			
			';

		
		//return output
		return $out;
	}
	
	
	add_action( 'vc_before_init', 'vc_exhibition_placeholder_single' );
	
	
	function vc_exhibition_placeholder_single() {	
		vc_map(array(
      "name" => esc_html__( "Exhibition Placeholder", "ievent" ),
      "base" => "exhibition_placeholder_single",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_exhbition-placeholder.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Exhibition Placeholder','TEXT_DOMAIN'),
      "params" => array(
		 		 
		array(
            "type" => "textarea",
            "class" => "",
            "heading" => esc_html__( "Company Lists", "ievent" ),
            "param_name" => "company_lists",
			"value" => "01.Rocko Co", //Default Counter Up Text
            "description" => esc_html__( "Type company names in seperated with comma", "TEXT_DOMAIN" )
         )	 
      )
   ));
    
	}



?>