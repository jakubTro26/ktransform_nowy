<?php 
	/* Accordion Group  ---------------------------------------------*/
	
	add_shortcode('accordion_group', 'ievent_accordion_group');
	
	function ievent_accordion_group($atts, $content = null) { 
		extract(shortcode_atts(array(
		'type' => '',
		'single_open' => 'yes'
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code
	
		if($single_open=='yes'):
		$single_open_class='accordion';
		else:
		$single_open_class='accordion-open';
		endif;
		
			$out  ='				
				<div class="jx-accordion '.$single_open_class.'">            
				<div id="accordion-1" class="none jx-toggle" data-accordion-group>'.do_shortcode($content).'</div>
				</div>
				<!-- According -->					
			';
		
		
				
		//return output
		return $out;
	}
	/* Accordion  ---------------------------------------------*/
	
	add_shortcode('accordion', 'ievent_accordion');
	
	function ievent_accordion($atts, $content = null) { 
		extract(shortcode_atts(array(
					'title' => 'Type title here',
					'description' => 'Type your content',
					'image' => '',
					'open' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$img_html='';
		
		$id = rand(0,1000); 
		
		//function code
		$img = wp_get_attachment_image_src($image, "small-blog");
	 	$imgSrc = $img[0];	
		if ($imgSrc):
		$img_html='<img src="'.$imgSrc.'" alt="" />';
		endif;
			$out ='
				<div id="'.$id.'" data-accordion="" class="jx-accordion-item head '.$open.' engine all">
					<div class="title" data-control=""><span class="jx-accordion-icon"></span>'.$title.'</div>
					<!-- According Title -->
					<div style="max-height: 0px; overflow: hidden;" data-content="">
					<div class="description">'.$img_html.$description.'</div>
					</div>
					<!-- According Content -->
					<div class="accordion-border"></div>
				</div>
			';
	
		
		//return output
		return $out;
	}
	
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_accordion' );
	
	
	function vc_accordion() {	
		
		vc_map( array(
			"name" => __("Accordion Group", "TEXT_DOMAIN"),
			"base" => "accordion_group",
			"as_parent" => array('only' => 'accordion'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			"is_container" => true,
			"params" => array(
				// add params same as with any other content element
				
			
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Single Open?",'TEXT_DOMAIN'),
				 "param_name" => "single_open",
				 "value" => array(   
						__('Select Option', 'TEXT_DOMAIN') => 'Select Option',
						__('Yes', 'TEXT_DOMAIN') => 'yes',
						__('No', 'TEXT_DOMAIN') => 'no'
						),
			)
				
			),
			"js_view" => 'VcColumnView'
		)
		 );
		
		
		vc_map( array(
			"name" => __("Single Accordion", "TEXT_DOMAIN"),
			"base" => "accordion",
			"content_element" => true,
			"as_child" => array('only' => 'accordion_group'), // Use only|except attributes to limit parent (separate multiple values with comma)
			"params" => array(
				// add params same as with any other content element
								
			
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Accordion Style",'TEXT_DOMAIN'),
				 "param_name" => "open",
				 "value" => array(   
						__('Select Your Style', 'TEXT_DOMAIN') => 'Select Accordion Style',
						__('Open', 'TEXT_DOMAIN') => 'open',
						__('Close', 'TEXT_DOMAIN') => 'close',
						),
			),
			
			
			
				array(
					"type" => "textfield",
					"heading" => __("Title", "TEXT_DOMAIN"),
					"param_name" => "title",
					"description" => __("Type tab title.", "TEXT_DOMAIN")
				),
				
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Image", "TEXT_DOMAIN" ),
					"param_name" => "image",
					"value" => "Select Your Image", //Default Counter Up Text
					"description" => esc_html__( "Add Image Here", "TEXT_DOMAIN" )
				 ),	
				
				array(
					 "type" => "textarea",
					 "holder" => "div",
					 "class" => "",
					 "heading" => __("Content",'TEXT_DOMAIN'),
					 "param_name" => "description",
					 "value" => "",
				)
				
			)
		) );
		//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
		if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
			class WPBakeryShortCode_accordion_group extends WPBakeryShortCodesContainer {
			}
		}
		if ( class_exists( 'WPBakeryShortCode' ) ) {
			class WPBakeryShortCode_accordion extends WPBakeryShortCode {
			}
		}
		
	}
?>