<?php 
	/* Exhibition Placeholder Group  ---------------------------------------------*/
	
	add_shortcode('agenda', 'jx_ievent_agenda');
	
	function jx_ievent_agenda($atts, $content = null) { 
		extract(shortcode_atts(array(
				'count' => '3'
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$day_1='';
		$tab_width='';
		$tab_id='';
		$tab_classid='';
		$hall_class='';
		$speaker_name='';
		$image='';
		
		global $post;
		
		
		$tab_id='ChildTab-1';
		$tab_classid='childtab_1';
		
		
		if ($count=='1'):
			$tab_width="full-width";
		elseif($count=='2'):
			$tab_width="half-width";
		elseif($count=='3'):			
			$tab_width="third-width";
		elseif($count=='4'):			
			$tab_width="fourth-width";
		elseif($count=='5'):			
			$tab_width="fifth-width";
		endif;
		
		//function code

		$main_tab='';
		$child_tab='';
		$day='';
		$j=1;
		
		$args = array('post_type' => 'agenda','orderby' => 'menu_order', 'order' => 'ASC','post_parent' => 0 ); 
			
		$loop = new WP_Query( $args ); 		
		while ( $loop->have_posts() ) : $loop->the_post();				
		
			$day='Day '.$j;		
			$main_tab .='<li class="resp-tab-item '.$tab_width.'">
					<div class="jx-ievent-tab-date jx-ievent-uppercase">'.get_the_title().'</div>
					<div class="jx-ievent-tab-day jx-ievent-uppercase">'.$day.'</div>
				</li>'; 				
 			
			$j++;
			
		endwhile;
		wp_reset_query();
		
		
		$out .='<div class="shortcode_tab_e jx-ievent-white-tab jx-ievent-arrow-tab">			
				<div id="ParentTab">
				<ul class="resp-tabs-list parenttab_1">';			
		$out .= $main_tab;				
		$out .='</ul>';		
		$out .='<div class="resp-tabs-container parenttab_1">';		
	
		$posts = get_pages( array( 'post_type' => 'agenda', 'numberposts' => -1, 'sort_column' => 'menu_order', 'order' => 'ASC', 'child_of' => 0, 'parent' => 0 ) );
		
		if ( $posts ) {
			
			
			$i=1;
			$count=0;
					
			foreach( $posts as $p ) {
			$tab_id='ChildTab-'.$i;
			$tab_classid='childtab_1';			 
			$child_posts = get_pages( array( 'post_type' => 'agenda', 'numberposts' => -1, 'sort_column' => 'menu_order', 'order' => 'ASC', 'child_of' => $p->ID, 'parent' => $p->ID ) );
			
			//var_dump($child_posts);
			
			$count = count($child_posts);
			
			if ($count=='2'):
				$hall_class="two-halls";
			endif;
			
			if ($count=='3'):
				$hall_class="three-halls";
			endif;
			
			if ($count=='4'):
				$hall_class="four-halls";
			endif;
			
			if ($count=='5'):
				$hall_class="five-halls";
			endif;
			
			if ($count=='6'):
				$hall_class="six-halls";
			endif;
			
			
			
			$out .='<div><div id="'.$tab_id.'">';
			$out .='<ul class="resp-tabs-list jx-ievent-subtab '.$tab_classid.' '.$hall_class.'">';					
			
			foreach( $child_posts as $p_child ) {				
			$out .='<li><div class="jx-ievent-tab-title">'.get_the_title( $p_child->ID ).'</div></li>';									
			}				
			
			$out .='</ul>';
			
			foreach( $child_posts as $p_child ) {

			$out .='<!-- EOF Child Tab Head -->					
					<div class="resp-tabs-container jx-ievent-event-schedule '.$tab_classid.'">
					<div>
					<div data-accordion-group class="jx-ievent-accordion-box">';
									
						
			$n_child_posts = get_pages( array( 'post_type' => 'agenda', 'numberposts' => -1, 'sort_column' => 'menu_order', 'order' => 'ASC', 'child_of' => $p_child->ID, 'parent' => $p_child->ID) );
			
			foreach( $n_child_posts as $p_child ) {
				
				if(has_post_thumbnail( $p_child->ID )):		
				$image ='<div class="image">'.get_the_post_thumbnail( $p_child->ID ).'</div>
						<!-- Image -->';
				$speaker_name='<div class="date"><i class="fa fa-clock-o"></i> <span>'.get_post_meta($p_child->ID,'jx_ievent_session_time',true).'</span> '.get_the_title( $p_child->ID ).'</div>';		
				
				elseif (get_post_meta($p_child->ID,'jx_ievent_session_icon',true)):
				$image = '<div class="image"><i class="fa '.get_post_meta($p_child->ID,'jx_ievent_session_icon',true).'"></i></div>';
				$speaker_name='';
				
				else:
				$image .='<div class="image"><img src="'.get_template_directory_uri().('/images/default_speaker.jpg').'" alt=""></div><!-- Image -->';
				endif;
				
								
				$out .='<div class="item"> 					  
						<div class="left-position">
						'.$image.'
						</div>
						<!-- Left item Position -->
						
						<div class="right-position">					
						<div data-accordion class="head">
							'.$speaker_name.'
							<div class="title" data-control>'.get_post_meta($p_child->ID,'jx_ievent_session_title',true).'</div>                        
							<!-- Title -->';
							
						$out .='<div data-content>
									<div class="content"><p>'.$p_child->post_content.'</p></div>
								</div>
								<!-- Content -->
									';
									
						$out .='
								</div>							
							</div>
						</div>					
						<!-- Item # 1 --> 
						<div class="clearfix"></div>';
									
			}
			//EOF loop item			
			$out .='</div></div></div>';			
			}
			
			$out .='</div></div>';		
			
	
			//Accordion Level										
				
			
			$i++;
		
			}
		}
		
		$out .='</div>';
				
		
		$out .='<div class="mb60"></div></div></div>';

				
		//return output
		return $out;
	}
	
	
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_ievent_agenda' );
	
	
	function vc_ievent_agenda() {	
		vc_map(array(
		  "name" => esc_html__( "Agenda", "ievent" ),
		  "base" => "agenda",
		  "class" => "",
		  "icon" => get_template_directory_uri().'/images/icon/vc_agenda.png',
		  "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
		  "description" => __('Add Agenda','TEXT_DOMAIN'),
		  "params" => array(
					 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Event Days", "TEXT_DOMAIN" ),
				"param_name" => "count",
				"value" => "3", 
				"description" => esc_html__( "Type total event days", "TEXT_DOMAIN" )
			 )
		  )
	   )); 
	}
	


?>