<?php 

	/* Venue  ---------------------------------------------*/
	
	add_shortcode('venue', 'ievent_venue');
	
	function ievent_venue($atts, $content = null) { 
		extract(shortcode_atts(array(
					'image' => '',
					'title' => 'Learn More About Ievent',
					'price' => '$83',
					'facility_a' => 'Wifi',
					'facility_b' => 'Family Rooms',
					'facility_c' => 'Smoking Rooms',
					'average_price_title' => 'Average Price Per Night',
					'average_point' => '9,1',
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 	$img = wp_get_attachment_image_src($image, "small-blog");

	 	$imgSrc = $img[0];
		
		//function code

			$out ='
			<div class="jx-venue">			
				<div class="jx-venue-item">

					<div class="image-hover">
						<div class="image"><img src="'.$imgSrc.'" alt=""></div>
						<!-- Image -->

						<!--<div class="average-point">'.$average_point.'</div> -->
						<!-- Average Point -->
						
						<div class="title">'.$title.'</div>
						<!-- Title -->
					</div>					

					<!-- Image - Hover -->					

					<div class="detail-list">
						<ul>
							<li><i class="fa fa-check-circle-o"></i> '.$facility_a.'</li>
							<li><i class="fa fa-check-circle-o"></i> '.$facility_b.'</li>
							<li><i class="fa fa-check-circle-o"></i> '.$facility_c.'</li>
						</ul>
					</div>
					<!-- Details -->
					
					<div class="average">
						<span class="average-title">'.$average_price_title.'</span>
						<span class="price">'.$price.'</span>
					</div>			
					<!-- Average Price -->
				</div>
			</div>';
			
		
		//return output
		return $out;
	}







	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_venue' );
	
	
	function vc_venue() {	
	vc_map(array(
      "name" => esc_html__( "Venue", "TEXT_DOMAIN" ),
      "base" => "venue",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_partners.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Venue','TEXT_DOMAIN'),
      "params" => array(
	  
	  

	array(
		"type" => "attach_image",
		"class" => "",
		"heading" => esc_html__( "Image", "TEXT_DOMAIN" ),
		"param_name" => "image",
		"value" => "Select Image", //Default Counter Up Text
		"description" => esc_html__( "Add Image Here", "TEXT_DOMAIN" )
	 ),
		 		 	
	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Title", "ievent" ),
		"param_name" => "title",
		"value" => "Learn More About Ievent", //Default Counter Up Text
		"description" => esc_html__( "Add Your Title Here", "TEXT_DOMAIN" )
	 ),

	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Facility A", "TEXT_DOMAIN" ),
		"param_name" => "facility_a",
		"value" => "Wifi", //Default Counter Up Text
		"description" => esc_html__( "Add Facility A", "TEXT_DOMAIN" )
	 ),

	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Facility B", "TEXT_DOMAIN" ),
		"param_name" => "facility_b",
		"value" => "Family Rooms", //Default Counter Up Text
		"description" => esc_html__( "Add Facility B", "TEXT_DOMAIN" )
	 ),

	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Facility C", "TEXT_DOMAIN" ),
		"param_name" => "facility_c",
		"value" => "Smoking Rooms", //Default Counter Up Text
		"description" => esc_html__( "Add Facility C", "TEXT_DOMAIN" )
	 ),
	 
	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Average Price Title", "TEXT_DOMAIN" ),
		"param_name" => "average_price_title",
		"value" => "Average Price Per Night", //Default Counter Up Text
		"description" => esc_html__( "Add Price Title", "TEXT_DOMAIN" )
	 ),


	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Price", "TEXT_DOMAIN" ),
		"param_name" => "price",
		"value" => "$83", //Default Counter Up Text
		"description" => esc_html__( "Add Price", "TEXT_DOMAIN" )
	 ),
		 
	array(
		"type" => "textfield",
		"class" => "",
		"heading" => esc_html__( "Rating", "TEXT_DOMAIN" ),
		"param_name" => "average_point",
		"value" => "9,1", //Default Counter Up Text
		"description" => esc_html__( "Add Rate", "TEXT_DOMAIN" )
	 )		 
		 
		
      )
   )); 
	}
	
	
?>