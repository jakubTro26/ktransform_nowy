<?php 


	/* Speaker  ---------------------------------------------*/
	
	add_shortcode('speakers', 'jx_ievent_speakers');
	
	function jx_ievent_speakers($atts, $content = null) { 
		extract(shortcode_atts(array(
					'type' =>'1',
					'title' => 'Meet Our',
					'bold_title' => 'Speakers',
					'count' => '8',
					'intro' =>'yes',
					'single_page' =>'yes',
					'button_icon' =>'Select Icon',
					'button_text' =>'Show Button',
					'button_link' =>'#',
					'speaker_id' =>''					
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$i=0;
		$intro_class='';
		
		global $ievent_data;
		
		
		if ($intro=='yes'):
		$intro_class='intro_class';
		endif;
		
		if($type=='1'):
		$type_class="jx-ievent-normal";
		$image_size="speaker-image";
		elseif($type=='2'):
		$type_class="jx-ievent-speaker-lg";
		$image_size="speaker-image-lg";
		endif;
		
		$out .='<div class="jx-ievent-speaker '.$type_class.' '.$intro_class.'">';
		
		
		if (($i==0) and ($intro=='yes')):
			
			$out .='
			<div class="jx-ievent-speaker-item jx-ievent-speaker-box-content">
				<div class="jx-ievent-title jx-ievent-uppercase">'.$title.'<span> '.$bold_title.'</span></div>
				<div class="jx-ievent-hr-title"></div>
				<p>'.do_shortcode($content).'</p>
			</div>
            <!-- Item Content Box-->';
		endif;
		
		$speaker_permalink='';
		
		if ($speaker_id):				
			$related_speakers = array_map( 'trim', explode( ',', $speaker_id ) );			
			$args = array('post_type' => 'speakers','orderby' => 'post__in', 'showposts' => $count,'post__in' => $related_speakers ); 		
		else:		
			$args = array('post_type' => 'speakers','orderby' => 'date', 'order' => 'ASC','showposts' => $count); 		
		endif;
		
		$loop = new WP_Query( $args ); 		
		while ( $loop->have_posts() ) : $loop->the_post();  
		//function code
			
			
			if (($ievent_data['speaker_view']=='pop-up')):
			$speaker_permalink='<a href="'.esc_url(get_permalink()).'?ajax=true&width=100%&height=500px" data-rel="prettyPhoto[ajax]">'.get_the_title().'</a>';
			elseif (($ievent_data['speaker_view']=='single-page')):
			$speaker_permalink='<a href="'.esc_url(get_permalink()).'">'.get_the_title().'</a>';
			endif;
			
			
			if ($single_page=='no'):
			$speaker_permalink=get_the_title();
			endif;
						
			
			$teammember_jobposition = get_post_meta(get_the_id(),'jx_ievent_speaker_position','ievent'); 			

			$out .='			
			<div class="jx-ievent-speaker-item">
				<div class="jx-ievent-speaker-photo jx-ievent-image-wrapper">'.get_the_post_thumbnail(get_the_ID(),$image_size).'
					<div class="jx-ievent-speaker-overlayer"></div>
					<div class="jx-ievent-image-hover-info">
						<div class="jx-ievent-speaker-name">'.$speaker_permalink.'</div>
						<div class="jx-ievent-speaker-pos">'.$teammember_jobposition.'</div>
						<div class="speaker-social">
                		<ul>';			
			
						if (get_post_meta(get_the_id(),'jx_ievent_speaker_fb','ievent')):
						$out .='<li><a href="http://www.facebook.com/'.get_post_meta(get_the_id(),'jx_ievent_speaker_fb','ievent').'"><i class="fa fa-facebook"></i></a></li>';
						endif;
						
						if (get_post_meta(get_the_id(),'jx_ievent_speaker_twitter','ievent')):
						$out .='<li><a href="http://www.twitter.com/'.get_post_meta(get_the_id(),'jx_ievent_speaker_twitter','ievent').'"><i class="fa fa-twitter"></i></a></li>';
						endif;
						
						if (get_post_meta(get_the_id(),'jx_ievent_speaker_linkedin','ievent')):
						$out .='<li><a href="http://www.linkedin.com/'.get_post_meta(get_the_id(),'jx_ievent_speaker_linkedin','ievent').'"><i class="fa fa-linkedin"></i></a></li>';
						endif;
						
						if (get_post_meta(get_the_id(),'jx_ievent_speaker_instagram','ievent')):
						$out .='<li><a href="http://www.instagram.com/'.get_post_meta(get_the_id(),'jx_ievent_speaker_instagram','ievent').'"><i class="fa fa-instagram"></i></a></li>';
						endif;
						
			$out .='</ul>
            </div></div>
				</div>
			</div>			
			<!-- Item -->
			';
			
			$i++;
			
		endwhile;
		wp_reset_query(); 
		
		
				
		$out .='</div>';  
		
		if($button_text):
		$out .='
		<div class="row"></div>
		<div class="row"></div>
		
		<div class="jx-ievent-btn-center"> 
			<a href="'.$button_link.'" class="jx-ievent-btn-default"><i class="line-icon vc_li '.$button_icon.'"></i>'.esc_html__('View All','ievent').'</a>
		</div>
		<!-- Read More Button -->
		';
		
		endif;

		
		//return output
		return $out;
	}
	
	
	
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_speaker' );
	
	
	function vc_speaker() {	
		vc_map(array(
      "name" => esc_html__( "Speakers", "TEXT_DOMAIN" ),
      "base" => "speakers",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_speaker.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Speakers','TEXT_DOMAIN'),
      "params" => array(
		 		 
        array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Type",'TEXT_DOMAIN'),
			 "param_name" => "type",
			 "value" => array(   
					__('Style A', 'TEXT_DOMAIN') => '1',
					__('Style B', 'TEXT_DOMAIN') => '2',
					),
		),
		
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
            "param_name" => "title",
			"value" => "Meet Our", //Default Counter Up Text
            "description" => esc_html__( "Type title here", "TEXT_DOMAIN" )
         ),
		 
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Bold Title", "TEXT_DOMAIN" ),
            "param_name" => "bold_title",
			"value" => "Speakers", //Default Counter Up Text
            "description" => esc_html__( "Bold title will go here", "TEXT_DOMAIN" )
         ),
		 
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Count", "TEXT_DOMAIN" ),
            "param_name" => "count",
			"value" => "8", //Default Counter Up Text
            "description" => esc_html__( "Number of speakers", "TEXT_DOMAIN" )
         ),
		 		 		 
		array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Intro",'TEXT_DOMAIN'),
			 "param_name" => "intro",
			 "value" => array(   
					__('Yes', 'TEXT_DOMAIN') => 'yes',
					__('No', 'TEXT_DOMAIN') => 'no',
					),
		),
		
		array(
			'type' => 'iconpicker',
			'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
			'param_name' => 'button_icon',
			'settings' => array(
			'emptyIcon' => false, // default true, display an "EMPTY" icon?
			'type' => 'linecons',
			'iconsPerPage' => 200, // default 100, how many icons per/page to display
			),
			'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
			'save_always' => true
		),
		
		
		array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Speaker Single Page",'TEXT_DOMAIN'),
			 "param_name" => "single_page",
			 "value" => array(   
					__('Yes', 'TEXT_DOMAIN') => 'yes',
					__('No', 'TEXT_DOMAIN') => 'no',
					),
		),
				
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Title", "TEXT_DOMAIN" ),
            "param_name" => "button_text",
			"value" => "More Speakers", //Default Counter Up Text
            "description" => esc_html__( "Type button text", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Link", "TEXT_DOMAIN" ),
            "param_name" => "button_link",
			"value" => "#", //Default Counter Up Text
            "description" => esc_html__( "Type button link", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Speakers IDs", "TEXT_DOMAIN" ),
            "param_name" => "speaker_id",
			"value" => "#", //Default Counter Up Text
            "description" => esc_html__( "Show specific speakers using post id e.g(234,345,23)", "TEXT_DOMAIN" )
         ),
		
		array(
			 "type" => "textarea",
			 "holder" => "div",
			 "class" => "",
			 "heading" => __("Content",'TEXT_DOMAIN'),
			 "param_name" => "content",
			 "value" => "",
		)
      )
   )); 
	}
	 
	
	


?>