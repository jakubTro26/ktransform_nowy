<?php 

	/* Event Play  ---------------------------------------------*/
	
	add_shortcode('img_placeholder', 'jx_ievent_img_placeholder');
	
	function jx_ievent_img_placeholder($atts, $content = null) { 
		extract(shortcode_atts(array(

			'image_url' => '',
			'title' => '',
			'position' => '',
			'link' => '',
			'class' => 'Type Class',		
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
			$img = wp_get_attachment_image_src($image_url, "large");	 
			$imgSrc = $img[0];
		//function code
			
			$out .='<div class="jx-ievent-placeholder-head '.$class.'">';
			
			if ($link):
			$out .='<a href="'.$link.'">';
			endif;
			
			$out .='			
				<div class="jx-ievent-image-placeholder '.$position.'">
					<img src="'.$imgSrc.'" alt="">
				</div>
			';
			
			if ($link):
			$out .='</a>';
			endif;
			
			$out .='</div>';
			

		//return output
		return $out;
	}




	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_img_placeholder' );
	
	
	function vc_img_placeholder() {	
		vc_map(array(
      "name" => esc_html__( "Image Placeholder", "ievent" ),
      "base" => "img_placeholder",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_gallery.png',
      "category" => esc_html__( "iEvent Shortcodes", "ievent"),
	  "description" => __('Add Image Placeholder','ievent'),
      "params" => array(
		 		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
            "param_name" => "title",
			"value" => "Meet Our", //Default Counter Up Text
            "description" => esc_html__( "Type Your Title Here", "TEXT_DOMAIN" )
         ),
		 
		array(
            "type" => "attach_image",
            "class" => "",
            "heading" => esc_html__( "Image URL", "TEXT_DOMAIN" ),
            "param_name" => "image_url",
			"value" => "Image Placeholder", //Default Counter Up Text
            "description" => esc_html__( "Add image", "TEXT_DOMAIN" )
         ),

		array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Position",'TEXT_DOMAIN'),
			 "param_name" => "position",
			 "value" => array(   
					__('top', 'TEXT_DOMAIN') => 'top',
					__('center', 'TEXT_DOMAIN') => 'center',
					__('bottom', 'TEXT_DOMAIN') => 'bottom',
					),
		),

		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Link", "TEXT_DOMAIN" ),
            "param_name" => "link",
			"value" => "Select image Link", //Default Counter Up Text
            "description" => esc_html__( "Add Image Link", "TEXT_DOMAIN" )
         ),


		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Class", "TEXT_DOMAIN" ),
            "param_name" => "class",
			"value" => "", //Default Counter Up Text
            "description" => esc_html__( "Add Your Class", "TEXT_DOMAIN" )
         )

      )
   )); 
	}
	 
?>