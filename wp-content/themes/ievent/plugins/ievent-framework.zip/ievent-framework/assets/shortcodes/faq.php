<?php 
	/* Price Table  ---------------------------------------------*/
	
	add_shortcode('faq', 'jx_ievent_faq');
	
	function jx_ievent_faq($atts, $content = null) { 
		extract(shortcode_atts(array(
					'open' => '',
					'color_style' => '',
					'description' => '',
					'post_count' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		$dark_light_color ="";
		
		if($color_style =="light") {
		$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
		$dark_light_color ="jx-ievent-dark";
		}

			$args = array('post_type' => 'faq','orderby' => 'date', 'order' => 'ASC','showposts' => $post_count ); 
			
			
		$out ='
		<div class="jx-ievent-faq">
		<div class="jx-ievent-faq-head">
			<div class="jx-ievent-faq-title">FAQ</div>
			<div class="jx-ievent-faq-description"><p>'.$description.'</p></div>
		</div>
		<!-- Title Section -->
		
		<div class="row"></div>
		
		<div class="jx-ievent-accordion '.$dark_light_color.'">                  
		<div div data-accordion-group class="jx-ievent-accordion-box">'; 

			
			
			$loop = new WP_Query( $args ); 		
			while ( $loop->have_posts() ) : $loop->the_post();  
			
			//function code
				
				$out .='				
				<div data-accordion class="head '.$open.'">
					<div class="title" data-control>'. get_the_title() .'</div>
					<!-- According Title -->
					<div data-content>
						<div class="description">'. get_the_content() .'</div>
					</div>
					<!-- According Content -->
					<div class="accordion-border"></div>
				</div>
				<!-- Accordion -->    
				';
	
			endwhile;  

		$out .='</div>
		</div></div>'; 			
			

		//return output
		return $out;
	}




?>