<?php 
	/* Interactive Map Group  ---------------------------------------------*/
	
	add_shortcode('interactive_map_group', 'jx_ievent_interactive_map_group');
	
	function jx_ievent_interactive_map_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'image' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code

		$out ='
			<div class="jx-ievent-interactive-map">
				<div class="jx-ievent-inter-map">
					'.get_the_post_thumbnail($image).'
					<img src="'.$image.'" alt="">
					<ul>'.do_shortcode($content).'</ul>
				</div>
			</div>
			'; 
				
		//return output
		return $out;
	}



	/* Interactive Map  ---------------------------------------------*/
	
	add_shortcode('interactive_point', 'jx_ievent_interactive_point');
	
	function jx_ievent_interactive_point($atts, $content = null) { 
		extract(shortcode_atts(array(
					'title' => '',
					'description' => '',
					'point_position' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='				
			<li class="jx-ievent-single-point">
			<a class="jx-ievent-img-replace" href="#0"></a>
			<div class="jx-ievent-more-info jx-ievent-top">
			<h2>'.$title.'</h2>
			<p>'.$description.'</p>
			<a href="#0" class="jx-ievent-close-info jx-ievent-img-replace">'.esc_html__('Close','ievent').'</a>
			</div>
			</li> 
			<!-- single-point -->
			';

		
		//return output
		return $out;
	}





	//Visual Composer
	
	add_shortcode('interactive_map_single', 'jx_ievent_interactive_map_single');
	
	function jx_ievent_interactive_map_single($atts, $content = null) { 
		extract(shortcode_atts(array(
					'image' => 'http://janxcode.com/ievent/images/exhibition-floor.png',
					'title_a' => 'Section A',
					'description_a' => 'Type your content Here',
					'point_a_x' => '10%',
					'point_a_y' => '40%',
					'title_b' => 'Section B',
					'description_b' => 'Type your content Here',
					'point_b_x' => '50%',
					'point_b_y' => '30%',
					'title_c' => 'Section C',
					'description_c' => 'Type your content Here',
					'point_c_x' => '70%',
					'point_c_y' => '40%',
					'title_d' => 'Section D',
					'description_d' => 'Type your content Here',
					'point_d_x' => '55%',
					'point_d_y' => '15%',
				), $atts)); 
		 
		
			//initial variables
			$out=''; 
			$img='';
		 

			$img = wp_get_attachment_image_src($image, "large");
	 
			$imgSrc = $img[0];
			
			$out .='
			<div class="jx-ievent-interactive-map">
			<div class="jx-ievent-inter-map">
			<img src="'.$imgSrc.'" alt="">
			<ul>
			'; 
			
			
			$out .='				
			<li class="jx-ievent-single-point" style="top:'.$point_a_y.'; left:'.$point_a_x.';">
			<a class="jx-ievent-img-replace" href="#0"></a>
			<div class="jx-ievent-more-info jx-ievent-top">
			<h2>'.$title_a.'</h2>
			<p>'.$description_a.'</p>
			<a href="#0" class="jx-ievent-close-info jx-ievent-img-replace">'.esc_html__('Close','ievent').'</a>
			</div>
			</li> 
			<!-- single-point -->
			
			<li class="jx-ievent-single-point" style="top:'.$point_b_y.'; left:'.$point_b_x.';">
			<a class="jx-ievent-img-replace" href="#0"></a>
			<div class="jx-ievent-more-info jx-ievent-top">
			<h2>'.$title_b.'</h2>
			<p>'.$description_b.'</p>
			<a href="#0" class="jx-ievent-close-info jx-ievent-img-replace">'.esc_html__('Close','ievent').'</a>
			</div>
			</li> 
			<!-- single-point -->

			<li class="jx-ievent-single-point" style="top:'.$point_c_y.'; left:'.$point_c_x.';">
			<a class="jx-ievent-img-replace" href="#0"></a>
			<div class="jx-ievent-more-info jx-ievent-top">
			<h2>'.$title_c.'</h2>
			<p>'.$description_c.'</p>
			<a href="#0" class="jx-ievent-close-info jx-ievent-img-replace">'.esc_html__('Close','ievent').'</a>
			</div>
			</li> 
			<!-- single-point -->
			
			<li class="jx-ievent-single-point" style="top:'.$point_d_y.'; left:'.$point_d_x.';">
			<a class="jx-ievent-img-replace" href="#0"></a>
			<div class="jx-ievent-more-info jx-ievent-top">
			<h2>'.$title_d.'</h2>
			<p>'.$description_d.'</p>
			<a href="#0" class="jx-ievent-close-info jx-ievent-img-replace">'.esc_html__('Close','ievent').'</a>
			</div>
			</li> 
			<!-- single-point -->
			';
			
			$out .='
			</ul>
			</div>
			</div>
			'; 
		
		

		
		//return output
		return $out;
	}




	add_action( 'vc_before_init', 'vc_interactive_map_single' );
	
	
	function vc_interactive_map_single() {	
		vc_map(array(
      "name" => esc_html__( "Interactive Map", "TEXT_DOMAIN" ),
      "base" => "interactive_map_single",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_exhibition.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Interactive Map','TEXT_DOMAIN'),
      "params" => array(
		 		 
        array(
            "type" => "attach_image",
            "class" => "",
            "heading" => esc_html__( "Image", "TEXT_DOMAIN" ),
            "param_name" => "image",
			"value" => "http://janxcode.com/ievent/images/exhibition-floor.png", //Default Counter Up Text
            "description" => esc_html__( "Add Image Here", "TEXT_DOMAIN" )
         ),

        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title A", "TEXT_DOMAIN" ),
            "param_name" => "title_a",
			"value" => "Section Title A", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
        array(
            "type" => "textarea",
            "class" => "",
            "heading" => esc_html__( "Description A", "TEXT_DOMAIN" ),
            "param_name" => "description_a",
			"value" => "Type Description Here", //Default Counter Up Text
            "description" => esc_html__( "Type Description Here", "TEXT_DOMAIN" )
         ),
		 
		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title B", "TEXT_DOMAIN" ),
            "param_name" => "title_b",
			"value" => "Section Title B", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
        array(
            "type" => "textarea",
            "class" => "",
            "heading" => esc_html__( "Description B", "TEXT_DOMAIN" ),
            "param_name" => "description_b",
			"value" => "Type Description Here", //Default Counter Up Text
            "description" => esc_html__( "Type Description Here", "TEXT_DOMAIN" )
         ),
		 
		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title C", "TEXT_DOMAIN" ),
            "param_name" => "title_c",
			"value" => "Section Title C", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
        array(
            "type" => "textarea",
            "class" => "",
            "heading" => esc_html__( "Description C", "TEXT_DOMAIN" ),
            "param_name" => "description_c",
			"value" => "Type Description Here", //Default Counter Up Text
            "description" => esc_html__( "Type Description Here", "TEXT_DOMAIN" )
         ),
		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title D", "TEXT_DOMAIN" ),
            "param_name" => "title_d",
			"value" => "Section Title D", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
        array(
            "type" => "textarea",
            "class" => "",
            "heading" => esc_html__( "Description D", "TEXT_DOMAIN" ),
            "param_name" => "description_d",
			"value" => "Type Description Here", //Default Counter Up Text
            "description" => esc_html__( "Type Description Here", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point A Left Position", "TEXT_DOMAIN" ),
            "param_name" => "point_a_x",
			"value" => "20%", //Default Counter Up Text
            "description" => esc_html__( "Set point A left position", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point A Top Position", "TEXT_DOMAIN" ),
            "param_name" => "point_a_y",
			"value" => "40%", //Default Counter Up Text
            "description" => esc_html__( "Set point A left position", "TEXT_DOMAIN" )
         ),	
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point B Left Position", "TEXT_DOMAIN" ),
            "param_name" => "point_b_x",
			"value" => "50%", //Default Counter Up Text
            "description" => esc_html__( "Set point B left position", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point B Top Position", "TEXT_DOMAIN" ),
            "param_name" => "point_b_y",
			"value" => "10%", //Default Counter Up Text
            "description" => esc_html__( "Set point B left position", "TEXT_DOMAIN" )
         ),	
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point C Left Position", "TEXT_DOMAIN" ),
            "param_name" => "point_c_x",
			"value" => "35%", //Default Counter Up Text
            "description" => esc_html__( "Set point C left position", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point C Top Position", "TEXT_DOMAIN" ),
            "param_name" => "point_c_y",
			"value" => "70%", //Default Counter Up Text
            "description" => esc_html__( "Set point C left position", "TEXT_DOMAIN" )
         ),	
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point D Left Position", "TEXT_DOMAIN" ),
            "param_name" => "point_d_x",
			"value" => "10%", //Default Counter Up Text
            "description" => esc_html__( "Set point D left position", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Point D Top Position", "TEXT_DOMAIN" ),
            "param_name" => "point_d_y",
			"value" => "10%", //Default Counter Up Text
            "description" => esc_html__( "Set point D left position", "TEXT_DOMAIN" )
         ),		 
		 
		 

		 

      )
   )); 
	}


?>