<?php 
/* Grid Image  ---------------------------------------------*/
	
	add_shortcode('gridimage_group', 'rebuild_gridimage_group');
	
	function rebuild_gridimage_group($atts, $content = null) { 
		extract(shortcode_atts(array(
				), $atts)); 
		 
		 
		//initial variables
	
		$out='';
			
		//function code
		
		$out .='<div class="jx-ievent-grid"><ul>'.do_shortcode($content).'</ul></div>';
		
		return $out;
	}
	
	
	
	add_shortcode('gridimage', 'rebuild_gridimage');
	
	function rebuild_gridimage($atts, $content = null) { 
		extract(shortcode_atts(array(
				'image' =>'',
				'title' =>'Multi-Page',
				'title_2' =>'One-Page',
				'link' =>'',
				'link_2' =>'',
				), $atts)); 
		 
		 
		//initial variables
	
		$out='';
		$ge_link_1='';
		$ge_link_2='';
		if ($title):
		$ge_link_1='<a href="'.$link.'"><div class="title title-1">'.$title.'</div></a>';
		endif;
		
		if($title_2):
		$ge_link_2='<a href="'.$link_2.'"><div class="title title-2 jx-black-bg">'.$title_2.'</div></a>';
		endif;
			
		
		//function code
		
		$out .='<li><img src="'.$image.'" alt="">
				<div class="jx-grid-image-btns">';
		
		$out .= $ge_link_1;
		
		$out .= $ge_link_2;				
				
		$out .='</div>
		</li>';
		
		return $out;
	}
	
	
    
    ?>