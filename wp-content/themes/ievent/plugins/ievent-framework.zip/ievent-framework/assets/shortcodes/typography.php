<?php 

	/* Listing  ---------------------------------------------*/
	
	add_shortcode('listing', 'jx_ievent_listing_group');
	
	function jx_ievent_listing_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'icon_list' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
	
		
		//function code
		$out = '<ul class="jx-lists">'.do_shortcode($atts['icon_list'],$content);
    	$out .= '</ul>';
			
		
		//return output
		return $out;
	}
	
	
	function li( $atts, $content = null ) {
		
		extract(shortcode_atts(array(
					'text' => 'Some text will go here'
				), $atts)); 
		
		return '<li><i class="fa '.$atts['icon_list'].'"></i>'.$text.'</li>';
	}
	add_shortcode('li', 'li');
	
	
	
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_listing' );
	
	
	function vc_listing() {	
		
		vc_map( array(
			"name" => __("Listing Group", "my-text-domain"),
			"base" => "listing",
			"as_parent" => array('only' => 'li'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			"is_container" => true,
			"params" => array(
				// add params same as with any other content element
				
			
				
			array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
					'param_name' => 'icon_list',
					'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'fontawesome',
					'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
					'save_always' => true
				),
				
			),
			"js_view" => 'VcColumnView'
		)
		 );
		
		
		vc_map( array(
			"name" => __("li", "TEXT_DOMAIN"),
			"base" => "li",
			"content_element" => true,
			"as_child" => array('only' => 'listing'), // Use only|except attributes to limit parent (separate multiple values with comma)
			"params" => array(
				// add params same as with any other content element
				
				array(
					"type" => "textfield",
					"heading" => __("Text", "TEXT_DOMAIN"),
					"param_name" => "text",
					"description" => __("Type your text here", "TEXT_DOMAIN")
				),
				
			)
		) );
		//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
		if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
			class WPBakeryShortCode_listing extends WPBakeryShortCodesContainer {
			}
		}
		if ( class_exists( 'WPBakeryShortCode' ) ) {
			class WPBakeryShortCode_li extends WPBakeryShortCode {
			}
		}
		
	}
	
	
	

?>