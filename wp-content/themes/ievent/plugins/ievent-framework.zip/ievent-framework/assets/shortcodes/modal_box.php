<?php 

	/* ModalBox  ---------------------------------------------*/
	
	add_shortcode('modal_box', 'jx_ievent_modal_box');
	
	function jx_ievent_modal_box($atts, $content = null) { 
		extract(shortcode_atts(array(		
		'id'=>'modal-box',	
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		//function code

		$out ='<div id="'.$id.'" class="jx-ievent-white-popup mfp-hide">'.do_shortcode($content).'</div>'; 
			
		
		//return output
		return $out;
	}


?>