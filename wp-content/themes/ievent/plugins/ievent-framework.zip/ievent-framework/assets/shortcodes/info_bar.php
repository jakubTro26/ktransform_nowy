<?php 
	
	/* Info Bar Shortcode  ---------------------------------------------*/
	
	add_shortcode('info_bar', 'jx_ievent_info_bar');
	
	function jx_ievent_info_bar($atts, $content = null) { 
		extract(shortcode_atts(array(
			'title_1' => 'Date',
			'description_1' => '',
			'title_2' => 'Location',
			'description_2' => '',
			'title_3' => 'Tickets',
			'description_3' => '',
			'title_4' => 'Speakers',
			'description_4' => '',
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='
			<ul>
			<li class="four columns">
				<div class="jx-ievent-info-bar-item">
					<div class="jx-ievent-info-icon"><i class="line-icon vc_li vc_li-calendar"></i></div>
					<div class="jx-ievent-info-content">
						<div class="info-title">'.$title_1.'</div>
						<div class="info-description">'.$description_1.'</div>
					</div>
				</div>
			</li>
			<!-- Item 01 -->
			
			<li class="five columns">
				<div class="jx-ievent-info-bar-item">
					<div class="jx-ievent-info-icon"><i class="line-icon vc_li vc_li-location"></i></div>
					<div class="jx-ievent-info-content">
						<div class="info-title">'.$title_2.'</div>
						<div class="info-description">'.$description_2.'</div>
					</div>
				</div>
			</li>
			<!-- Item 02 -->
			
			<li class="four columns">
				<div class="jx-ievent-info-bar-item">
					<div class="jx-ievent-info-icon"><i class="line-icon vc_li vc_li-tag"></i></div>
					<div class="jx-ievent-info-content">
						<div class="info-title">'.$title_3.'</div>
						<div class="info-description">'.$description_3.'</div>
					</div>
				</div>
			</li>
			<!-- Item 03 -->
			
			<li class="three columns">
				<div class="jx-ievent-info-bar-item">
					<div class="jx-ievent-info-icon"><i class="line-icon vc_li vc_li-megaphone"></i></div>
					<div class="jx-ievent-info-content">
						<div class="info-title">'.$title_4.'</div>
						<div class="info-description">'.$description_4.'</div>
					</div>
				</div>
			</li>
			<!-- Item 04 -->
			</ul>
			';

		
		//return output
		return $out;
	}


?>