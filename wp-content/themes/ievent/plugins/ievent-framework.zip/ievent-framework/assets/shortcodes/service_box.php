<?php 
	/* Service Box Group  ---------------------------------------------*/
	
	add_shortcode('service_box_group', 'jx_ievent_service_box_group');
	
	function jx_ievent_service_box_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'color_style' => '',
					'type' => ''
					
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		$dark_light_color = "";
		
		if($color_style =="light") {
		$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
		$dark_light_color ="jx-ievent-dark";
		}
		
		
		if($type =='Style A'):
			$class="jx-ievent-servicebox-1";
		elseif($type =='Style B'):
			$class="jx-ievent-servicebox-2";
		endif;
		
		
		//function code

		$out ='<div class="'.$class.' '.$dark_light_color.'">'.do_shortcode($content).'</div>'; 
			
		
		//return output
		return $out;
	}



	/* Service Box  ---------------------------------------------*/
	
	add_shortcode('service_box', 'jx_ievent_service_box');
	
	function jx_ievent_service_box($atts, $content = null) { 
		extract(shortcode_atts(array(
					'icon' => '',
					'title' => ''					
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		//function code
			
			$out ='				
				<div class="one-third columns jx-ievent-service-item">
					<div class="service-icon"><i class="line-icon '.$icon.'"></i></div>
					<div class="service-title jx-ievent-uppercase"><a href="#">'.$title.'</a></div>
					<div class="service-title-border"></div>
					<div class="service-description">
						<p>'.do_shortcode($content).'</p>
					</div>
				</div>
				<!-- item 01 -->
			';

		
		//return output
		return $out;
	}
	
	
	
	//Visual Composer
	
	add_shortcode('service_box_single', 'jx_ievent_service_single_box');
	
	function jx_ievent_service_single_box($atts, $content = null) { 
		extract(shortcode_atts(array(
					'icon' => '',
					'title' => '',
					'link' => '',
					'color_style' => '',
					'type' => '1'			
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$class='';
		 
		$dark_light_color = "";
		
		if($color_style =="light") {
		$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
		$dark_light_color ="jx-ievent-dark";
		}
		
		
		if($type =='1'):
			$class="jx-ievent-servicebox-1";
		elseif($type =='2'):
			$class="jx-ievent-servicebox-2";
		elseif($type =='3'):
			$class="jx-ievent-servicebox-3";
		endif;
		
		//function code
			$out ='<div class="'.$class.' '.$dark_light_color.'">			
					<div class="jx-ievent-service-item">
						<div class="service-icon"><i class="line-icon '.$icon.'"></i></div>
						<div class="service-title jx-ievent-uppercase"><a href="'.$link.'">'.$title.'</a></div>
						<div class="service-title-border"></div>
						<div class="service-description">
							<p>'.do_shortcode($content).'</p>
						</div>
					</div>
					<!-- item 01 -->
				</div>
			';

		
		//return output
		return $out;
	}
	
	
	add_action( 'vc_before_init', 'vc_service_box' );
	
	
	function vc_service_box() {	
		vc_map(array(
		  "name" => esc_html__( "Service Box", "TEXT_DOMAIN" ),
		  "base" => "service_box_single",
		  "class" => "",
		  "icon" => get_template_directory_uri().'/images/icon/vc_servicebox.png',
		  "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
		  "description" => __('Add Container','TEXT_DOMAIN'),
		  "params" => array(
					 
	
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Your Color Style",'TEXT_DOMAIN'),
				 "param_name" => "color_style",
				 "value" => array(   
						__('Light', 'TEXT_DOMAIN') => 'light',
						__('Dark', 'TEXT_DOMAIN') => 'dark',
						),
			),
			
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Your Type",'TEXT_DOMAIN'),
				 "param_name" => "type",
				 "value" => array(   
						__('Style A', 'TEXT_DOMAIN') => '1',
						__('Style B', 'TEXT_DOMAIN') => '2',
						__('Style C', 'TEXT_DOMAIN') => '3',
						),
			),
	
	
		 
			 array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
					'param_name' => 'icon',
					'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'linecons',
					'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
					'save_always' => true
				),
	
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
				"param_name" => "title",
				"value" => "Some Title", 
				"description" => esc_html__( "Add Your Title Here", "TEXT_DOMAIN" )
			 ),
			 
			 array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Link", "TEXT_DOMAIN" ),
				"param_name" => "link",
				"value" => "#", 
				"description" => esc_html__( "Add link here", "TEXT_DOMAIN" )
			 ),
			 
			array(
				 "type" => "textarea",
				 "holder" => "div",
				 "class" => "",
				 "heading" => __("Content",'TEXT_DOMAIN'),
				 "param_name" => "content",
				 "value" => "",
			)
	
					 
		  )
	   ));
    
	}



?>