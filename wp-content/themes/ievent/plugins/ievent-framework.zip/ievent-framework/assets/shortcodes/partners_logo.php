<?php 

	/* Partners Logo  ---------------------------------------------*/
	
	add_shortcode('partners_logo', 'jx_ievent_partners_logo');
	
	function jx_ievent_partners_logo($atts, $content = null) { 
		extract(shortcode_atts(array(
					'post_count' => '',
					'title' => '',
					'category' => '',
					'blank_window' => 'no',
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$title_section='';
		$blank_window_code='';
		
		if($blank_window =='yes'):
			$blank_window_code ="target='_blank'";
		else:
			$blank_window_code='';		
		endif;
		
		if($title):
			$title_section ='<div class="jx-ievent-section-title">'.$title.'</div>';
		endif;
		
		$out .='<div class="jx-ievent-sponsors">'.$title_section.'<ul>';			
		 
		if($category): 
		$args = array('post_type' => 'partners',
						'tax_query' => array(
							array(
								'taxonomy' => 'partners-category',
								'field' => 'slug',
								'terms' => $category,
							)
						),
					  'orderby' => 'menu_order',
					  'order' => 'ASC',
					  'showposts' => $post_count ); 
					  
		else:
		$args = array('post_type' => 'partners',
					  'orderby' => 'menu_order',
					  'order' => 'ASC',
					  'showposts' => $post_count ); 
		endif;
		
					  
		$loop = new WP_Query( $args ); 		
		while ( $loop->have_posts() ) : $loop->the_post();  
		
			
			if(get_the_category()):
				$cats = get_the_category(); 
			    $cat_name = $cats[0]->name;
			endif;
			
			$images = rwmb_meta( 'jx_ievent_partner_logo', 'type=image_advanced' );
					
			foreach ( $images as $image ){
				$images_url=$image['full_url'];
			}	
			 	
		//function code
			
			$out .='<li><a href="'.get_post_meta(get_the_ID(),'jx_ievent_partner_link',true ).'" '.$blank_window_code.'><div class="slide-contents"><img src="'.esc_url($images_url).'" alt=""></div></a></li>';
		endwhile;
		wp_reset_query(); 
		
		$out .='</ul></div>';	
		
		//return output
		return $out;
	}





	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_partners_logo' );
	
	
	function vc_partners_logo() {	
		vc_map(array(
      "name" => esc_html__( "Partners Logo", "TEXT_DOMAIN" ),
      "base" => "partners_logo",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_partners.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Partners Logo','TEXT_DOMAIN'),
      "params" => array(
		 		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Post Count", "TEXT_DOMAIN" ),
            "param_name" => "post_count",
			"value" => "5", //Default Counter Up Text
            "description" => esc_html__( "You Can change Count", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
            "param_name" => "title",
			"value" => "Gold Partner", //Default Counter Up Text
            "description" => esc_html__( "Type Title", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Category", "TEXT_DOMAIN" ),
            "param_name" => "category",
			"value" => "Gold", //Default Counter Up Text
            "description" => esc_html__( "Type Partner Category", "TEXT_DOMAIN" )
         ),
		 
		 array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Open in Blank Page",'TEXT_DOMAIN'),
			 "param_name" => "blank_window",
			 "value" => array(   
				__('Yes/NO', 'TEXT_DOMAIN') => '',
				__('Yes', 'TEXT_DOMAIN') => 'yes',
				__('No', 'TEXT_DOMAIN') => 'no'
					),
		),


		 
		
      )
   )); 
	}
	 
	






?>