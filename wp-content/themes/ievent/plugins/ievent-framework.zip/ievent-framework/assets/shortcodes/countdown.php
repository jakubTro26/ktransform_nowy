<?php

  /* Countdown  ---------------------------------------------*/
  
  add_shortcode('countdown', 'jx_ievent_countdown');
  
  function jx_ievent_countdown($atts, $content = null) {
    extract(shortcode_atts(array(    
      'type' => '1',
      'title' => 'HURRY UP!!',
      'description' => 'Viverra dignissim elit. Maecenas in orci nisl. Cras et nisl aliquet, mollis purus ac, vestibulum metus.',
      'event_date' => '12 jan 2017',
      'event_time' => '12:00:00',
      'btn_text' => 'BUY NOW',
      'btn_link' => 'http://themeforest.net/item/ievent-event-conference-wordpress-theme/13397512'
    ), $atts));
    
    global $ievent_data;
    
    //initial variables
    $out='';
    $intro='';
    $button_code='';
    $count_classes='';
    
    if(($title)||($description)):
    $intro ='<h1>'.$title.'</h1>
                    <p>'.$description.'</p>';
    endif;
    
    if($btn_text):
    $button_code =' <div class="row"></div>
                    <div class="jx-ievent-btn-center">
                        <a href="'.$btn_link.'" class="jx-ievent-btn-default jx-ievent-outline jx-ievent-white-btn">'.$btn_text.'</a>
                    </div>';
    endif;
    
    //function code
    $count_down='';
  
    if ($type=='1'):
    $count_classes='jx-ievent-countdown-box counter-box-1 jx-ievent-default-bg jx-ievent-half-width right';
    elseif ($type=='2'):
    $count_classes='jx-ievent-countdown-box-2';
    endif;  
      
    if($ievent_data['info_countdown_date']):
      $count_down = $ievent_data['info_countdown_date'];
    else:
      $count_down =$ievent_data.' '.$event_time;
    endif; 
      
      
      $out ='
                <div class="'.$count_classes.'" data-time="'.$count_down.'">
                  '.$intro.'
                    
                    <div class="jx-ievent-countdown">
                      <div class="dsb-theme-wrapper countdown">
                        <div class="dsb-theme">
                            <div class="counter-wrapper">
                                <ul>
                                    <li>
                                        <div class="days count">00</div>
                                        <div class="textDays count-text">'.esc_html__('Days','ievent').'</div>
                                    </li>
                                    <li>
                                        <div class="hours count">00</div>
                                        <div class="textHours count-text">'.esc_html__('Hours','ievent').'</div>
                                    </li>
                                    <li>
                                        <div class="minutes count">00</div>
                                        <div class="textmins count-text">'.esc_html__('Mins','ievent').'</div>
                                    </li>
                                    <li>
                                        <div class="seconds count">00</div>
                                        <div class="textSecs count-text">'.esc_html__('Secs','ievent').'</div>
                                    </li>
                                </ul>
                                <div class="jC-clear"></div>
                            </div>
                            
                        </div>
                    </div>                    
                    </div>
                    
                   '.$button_code.'
                
                </div>
                <!-- EOF Countdown Form -->
      ';
      

    //return output
    return $out;
  }



  //Visual Composer
  
  
  add_action( 'vc_before_init', 'vc_countdown' );
  
  
  function vc_countdown() {  
    vc_map(array(
      "name" => esc_html__( "Countdown", "TEXT_DOMAIN" ),
      "base" => "countdown",
      "class" => "",
    "icon" => get_template_directory_uri().'/images/icon/vc_countdown.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
    "description" => __('Add Countdown','TEXT_DOMAIN'),
      "params" => array(
          
        
    array(
       "type" => "dropdown",
       "class" => "",
       "heading" => __("Type",'TEXT_DOMAIN'),
       "param_name" => "type",
       "value" => array(   
          __('Style A', 'TEXT_DOMAIN') => '1',
          __('Style B', 'TEXT_DOMAIN') => '2',
          ),
    ),
    
    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
            "param_name" => "title",
      "value" => "Hurry Up!!", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
     
     array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Description", "TEXT_DOMAIN" ),
            "param_name" => "description",
      "value" => "Viverra dignissim elit. Maecenas in orci nisl. Cras et nisl aliquet, mollis purus ac, vestibulum metus.", //Default Counter Up Text
            "description" => esc_html__( "Short Description", "TEXT_DOMAIN" )
         ),
     
     array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Event Date", "TEXT_DOMAIN" ),
            "param_name" => "event_date",
      "value" => "25 Jan 2017", //Default Counter Up Text
            "description" => esc_html__( "Event Date", "TEXT_DOMAIN" )
         ),
     
     array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Event Time", "TEXT_DOMAIN" ),
            "param_name" => "event_time",
      "value" => "12:00:00", //Default Counter Up Text
            "description" => esc_html__( "Event Time", "TEXT_DOMAIN" )
         ),
      
      array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Text", "TEXT_DOMAIN" ),
            "param_name" => "btn_text",
      "value" => "BUY NOW", //Default Counter Up Text
            "description" => esc_html__( "Type Button Text", "TEXT_DOMAIN" )
         ),
     array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Link", "TEXT_DOMAIN" ),
            "param_name" => "btn_link",
      "value" => "#", //Default Counter Up Text
            "description" => esc_html__( "Type Button Link", "TEXT_DOMAIN" )
         )
     
      )
   ));
  }



?>