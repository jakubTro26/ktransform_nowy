<?php
require_once($get_plugin_dir_path.'/assets/tinymce_button.php');
require_once($get_plugin_dir_path.'/assets/inc/cpt.php');


//One-Click Importer
require_once($get_plugin_dir_path.'/one-click-importer/ievent-importer.php');


function the_content_filter($content) {
// array of custom shortcodes requiring the fix
$block = join("|",array("media_center_group","media_center","counter_up_group","counter_up","price_table_group","price_table","testimonials_group","testimonials","service_box_group","service_box","partners","partners_logo","speakers_group","speakers","subscribe","section_title_group","section_title","contact_us","map","faq_group","faq","interactive_map_group","interactive_point","exhibition_placeholder_group","exhibition_placeholder","exhibition_placeholder_point","tabs_group","tab_content_group","accordion_group","tab","subtabs_group","tabs_point","portfolio_group","portfolio_tab_group","portfolio_tab","portfolio_image_group","portfolio_image","portfolio","registration","countdown","container","container_intro","slider","event_box","event_play","event_counter","event_form","info_bar","img_placeholder",'eight_columns','four_columns','third_columns','row','infobox','contact_infobox','ten_columns','six_columns','modal_box' , 'accordion','progress_bar_group','progress_bar' ,'icon_box' ,'venue','grid-image'));
// opening tag
$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
return $rep;
} 
add_filter("the_content", "the_content_filter");
//Shortcodes Include
include('shortcodes/media_center.php');
include('shortcodes/counter_up.php');
include('shortcodes/price_table.php');
include('shortcodes/testimonials.php');
include('shortcodes/service_box.php');
include('shortcodes/partners_logo.php');
include('shortcodes/speakers.php');
include('shortcodes/subscribe.php');
include('shortcodes/section_title.php');
include('shortcodes/contact_us.php');
include('shortcodes/container.php');
include('shortcodes/container_intro.php');
include('shortcodes/map.php');
include('shortcodes/faq.php');
include('shortcodes/interactive_map.php');
include('shortcodes/exhibition_placeholder.php');
include('shortcodes/tabs.php');
include('shortcodes/portfolio.php');
include('shortcodes/registration.php');
include('shortcodes/countdown.php');
include('shortcodes/slider.php');
include('shortcodes/event_box.php');
include('shortcodes/event_play.php');
include('shortcodes/event_counter.php');
include('shortcodes/event_form.php');
include('shortcodes/info_bar.php');
include('shortcodes/image_placeholder.php');
include('shortcodes/columns.php');
include('shortcodes/infobox.php');
include('shortcodes/modal_box.php');
include('shortcodes/agenda.php');
include('shortcodes/accordion.php');
include('shortcodes/progress_bar.php');
include('shortcodes/icon_box.php');
include('shortcodes/venue.php');
include('shortcodes/grid-image.php');
?>